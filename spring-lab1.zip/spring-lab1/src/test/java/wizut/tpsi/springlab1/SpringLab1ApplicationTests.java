package wizut.tpsi.springlab1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLab1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
